import { Link } from "react-router-dom";

const Header = () => (
  <header className="bg-purple-500 p-4 text-white shadow-md">
    <div className="container mx-auto flex justify-between items-center">
      <Link to="/users" className="text-3xl font-bold">Users Page</Link>
    </div>
  </header>
);

export default Header;
