import { Link } from "react-router-dom";

const NotFound = () => (
  <div className="flex flex-col items-center justify-center text-center">
    <h1 className="text-9xl font-bold text-red-500">404</h1>
    <p className="text-2xl mt-2">Страница не найдена</p>
    <Link to="/users" className="mt-4 bg-red-500 text-white px-6 py-2 rounded-lg hover:bg-red-700">
      Вернуться на главную
    </Link>
  </div>
);

export default NotFound;
