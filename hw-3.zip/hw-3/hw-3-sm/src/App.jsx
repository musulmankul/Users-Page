import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';
import UserList from './pages/UserList';
import UserDetails from './pages/UserDetails';
import NotFound from './pages/NotFound';
import "./App.css";

const App = () => (
  <Router>
    <Header />
    <Routes>
      <Route path="/" element={<Navigate to="/users" />} />
      <Route path="/users" element={<UserList />} />
      <Route path="/user/:id" element={<UserDetails />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  </Router>
);

export default App;
